<div class="row">
	<div class="col m 12">
		<h5>Profil Perpustakaan SMK Muhammadiyah</h5>
	</div>
</div>

<div class="row">
	<div class="col m6">
		<div class="card-panel teal darken-2 white-text">
			<h6><b>Visi</b></h6>
			<p>
				"Terwujudnya Peserta Didik Cerdas Melalui Gemar Membaca Dengan Memberdayakan Perpustakaan"
			</p><br>
			<h6><b>Misi</b></h6>
			<br>
			1. Terwujudnya layanan prima.

			<br>
			2. Terwujudnya perpustakaan sebagai pelestari khazanah budaya bangsa.

			<br>
			3. Terwujudnya perpustakaan sesuai standar nasional perpustakaan.
		</div>
	</div>
	<div class="col m6">
		<div class="card-panel teal darken-2 white-text">
			<h6><b>Identitas Perpustakaan</b></h6>
			<hr>
			<p>
				Perpustakaan SMK Muhammadiyah 2 Pekanbaru adalah tempatnya seluruh warga SMK Muhammadiyah 2 Pekanbaru untuk mencari informasi atau ilmu pengetahuan dan tempat terbaik untuk menghabiskan waktu.
			</p>
		</div>
	</div>
</div>